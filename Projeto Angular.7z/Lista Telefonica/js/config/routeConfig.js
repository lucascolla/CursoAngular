angular.module("listaTelefonica").config(function($routeProvider) {
    $routeProvider.when("/contatos", {
        templateUrl: "view/lista.html",
        controller: "listaTelefonicaCtrl"
    });

    $routeProvider.when("/form", {
        templateUrl: "view/form.html",
        controller: "listaTelefonicaCtrl"
    });

    $routeProvider.otherwise({ redirectTo: "/contatos" });
});